<?php

namespace Drupal\employee\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Queue\QueueFactory;
use Symfony\Component\DependencyInjection\ContainerInterface;

class QueueForm extends FormBase {

  /**
   * The queue factory service.
   *
   * @var \Drupal\Core\Queue\QueueFactory
   */
  protected $queueFactory;

  /**
   * Constructs a new BatchForm.
   *
   * @param \Drupal\Core\Queue\QueueFactory $queue_factory
   *   The queue factory service.
   */
  public function __construct(QueueFactory $queue_factory) {
    $this->queueFactory = $queue_factory;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('queue')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'batch_process_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
   
    // Define some sample data for name components and genders.
    $firstNames = ['John', 'Jane', 'Alice', 'Robert', 'Michael', 'Emily', 'James', 'Mary', 'David', 'Sarah'];
    $lastNames = ['Smith', 'Johnson', 'Brown', 'Williams', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez'];
    $genders = ['male', 'female'];
    $statuses = ['active', 'inactive'];
    
    // Start ID from 4 since you already have 3 records.
    for ($i = 1; $i <= 500; $i++) {
        $firstName = $firstNames[array_rand($firstNames)];
        $lastName = $lastNames[array_rand($lastNames)];
        $gender = $genders[array_rand($genders)];
        $status = $statuses[array_rand($statuses)];
        
        $result[] = [
            'id' => $i,
            'name' => "$firstName $lastName",
            'email' => strtolower("$firstName.$lastName@dummy.com"),
            'gender' => $gender,
            'status' => $status,
        ];
    }
    
    // Now $result contains 5003 records.
    

    // Get the queue.
    $queue = $this->queueFactory->get('employee_node_queue_worker');

    // Add each item to the queue.
    foreach ($result as $nodeData) {
      $queue->createItem($nodeData);
    }

    \Drupal::messenger()->addStatus($this->t('Data has been added to the queue for processing.'));
  }

}
