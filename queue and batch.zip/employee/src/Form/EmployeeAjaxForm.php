<?php

namespace Drupal\employee\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
// use Drupal\Core\Database\Database;

class EmployeeAjaxForm extends FormBase{

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
        return 'employee_ajax_form';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state) {
        $form['element'] = [
            '#type' => 'markup',
            '#markup' => "<div class='success'></div>",
        ];

        $form['first_name'] = [
            '#type' => 'textfield',
            '#title' => $this->t('First Name'),
            '#required' => TRUE,
        ];

        $form['last_name'] = [
            '#type' => 'textfield',
            '#title' => $this->t('Last Name'),
            '#required' => TRUE,
        ];

        $form['employee_email'] = [
            '#type' => 'textfield',
            '#title' => $this->t('Email'),
            '#required' => TRUE,
        ];

        $form['action'] = [
            '#type' => 'action',
        ];

        $form['actions']['submit'] = [
            '#type' => 'button',
            '#value' => $this->t('Submit'),
            '#ajax' => [
                'callback' => '::SubmitForm',
                'progress' => [
                    'type' => 'throbber',
                    'message' => $this->t('Searching products ...'),
                ],
            ]
        ];

        return $form;
    }

    public function SubmitForm(array &$form, FormStateInterface $form_state){
        $ajax_response = new AjaxResponse();
        // $conn = Database::getConnection();

        // $formField = $form_state->getValues();

        // $formData['emp_firstname'] = $formField['first_name'];
        // $formData['emp_lastname'] = $formField['last_name'];
        // $formData['emp_email'] = $formField['employee_email'];

        // $conn->insert('employee')
        // ->fields($formData)
        // ->execute();
        $ajax_response->addCommand(new HtmlCommand('.success', 'Form Submitted Successfully'));
        return $ajax_response;

    }
}