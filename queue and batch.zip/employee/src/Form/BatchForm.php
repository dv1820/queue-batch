<?php

namespace Drupal\employee\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\employee\CustomBatch;

class BatchForm extends FormBase {

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
        return 'batch_process_form';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state) {
        $form['submit'] = [
            '#type' => 'submit',
            '#value' => $this->t('Submit'),
        ];

        return $form;
    }

    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state) {
        $result = [
            [
                'id' => 1,
                'name' => 'Robert Brown',
                'email' => 'robert.brown@example.com',
                'gender' => 'male',
                'status' => 'active',
            ],
            [
                'id' => 2,
                'name' => 'Jane Smith',
                'email' => 'jane.smith@dummy.com',
                'gender' => 'female',
                'status' => 'inactive',
            ],
            [
                'id' => 3,
                'name' => 'Alice Johnson',
                'email' => 'alice.johnson@dummy.com',
                'gender' => 'female',
                'status' => 'active',
            ],
        ];
        
        $operations = [];
        foreach ($result as $nodeData) {
            $operations[] = [
                [CustomBatch::class, 'batchOperation'],
                [$nodeData],
            ];
        }

        $batch = [
            '#title' => $this->t('Inserting...'),
            'operations' => $operations,
            'finished' => [CustomBatch::class, 'batchFinish'],
        ];
        
        batch_set($batch);
    }
}
