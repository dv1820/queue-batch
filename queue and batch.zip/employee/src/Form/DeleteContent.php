<?php

namespace Drupal\employee\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\Core\Database\Database;

/**
 * Provides a form to delete all nodes of a particular content type.
 */
class DeleteContent extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'delete_content_by_type_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // Get all content types
    $content_types = \Drupal::service('entity_type.manager')
      ->getStorage('node_type')
      ->loadMultiple();

    $options = [];
    foreach ($content_types as $type) {
      $options[$type->id()] = $type->label();
    }

    $form['content_type'] = [
      '#type' => 'select',
      '#title' => $this->t('Select content type to delete'),
      '#options' => $options,
      '#required' => TRUE,
    ];

    $form['actions'] = [
      '#type' => 'actions',
    ];
    
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Delete All Content'),
      '#button_type' => 'primary',
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Get the selected content type
    $content_type = $form_state->getValue('content_type');

    if ($content_type) {
      // Load all nodes of the selected content type
      $nids = \Drupal::entityQuery('node')
        ->condition('type', $content_type)
        ->accessCheck(FALSE)
        ->execute();

      if (!empty($nids)) {
        $nodes = Node::loadMultiple($nids);
        foreach ($nodes as $node) {
          $node->delete();
        }
        \Drupal::messenger()->addMessage($this->t('All nodes of content type %type have been deleted.', ['%type' => $content_type]));
      }
      else {
        \Drupal::messenger()->addWarning($this->t('No nodes found for content type %type.', ['%type' => $content_type]));
      }
    }
    else {
      \Drupal::messenger()->addError($this->t('No content type selected.'));
    }
  }
}
