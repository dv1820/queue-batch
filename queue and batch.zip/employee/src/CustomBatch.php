<?php

namespace Drupal\employee;

use Drupal\node\Entity\Node;

class CustomBatch {

    /**
     * Batch operation callback.
     */
    public static function batchOperation($nodeData, &$context) {
        $id = $nodeData['id'];
        $name = $nodeData['name'];
        $email = $nodeData['email'];
        $gender = $nodeData['gender'];
        $status = $nodeData['status'];

        $node = Node::create([
            'type' => 'employee_data',
            'title' => $name,
            'field_id' => $id,
            'field_namee' => $name,
            'field_emailll' => $email,
            'field_gender' => $gender,
            'field_status' => $status,
        ]);

        $node->save();
        $context['result'][] = $nodeData;
    }

    /**
     * Batch finished callback.
     */
    public static function batchFinish($success, $results, $operations) {
        if ($success) {
            \Drupal::messenger()->addStatus(t('Data entered successfully.'));
        }
        else {
            \Drupal::messenger()->addError(t('Some error occurred.'));
        }
    }
}
