<?php

namespace Drupal\employee\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\node\Entity\Node;

/**
 * Processes node creation for employee data.
 *
 * @QueueWorker(
 *   id = "employee_node_queue_worker",
 *   title = @Translation("Employee Node Queue Worker"),
 *   cron = {"time" = 60}
 * )
 */
class EmployeeNodeQueueWorker extends QueueWorkerBase {

  /**
   * {@inheritdoc}
   */
  public function processItem($data) {
    // Process each item in the queue.
    $id = $data['id'];
    $name = $data['name'];
    $email = $data['email'];
    $gender = $data['gender'];
    $status = $data['status'];

    $node = Node::create([
      'type' => 'employee_data',
      'title' => $name,
      'field_id' => $id,
      'field_namee' => $name,
      'field_emailll' => $email,
      'field_gender' => $gender,
      'field_status' => $status,
    ]);

    $node->save();
  }

}
