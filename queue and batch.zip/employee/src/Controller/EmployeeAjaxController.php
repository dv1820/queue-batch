<?php

namespace Drupal\employee\Controller;

use Drupal\Core\Controller\ControllerBase;

class EmployeeAjaxController extends ControllerBase {

    public function modallink(){
        $build = [
            '#markup' => '<a href="/employee-Ajax-form" class="use-ajax" data-dialog-type="modal" >Click Here</a>'
        ];
        return $build;
    }
}